"""Footprint iteration helpers wrapping the kipy board API.

Provides a kipy-independent dict representation of footprints so plugin code
doesn't call kipy directly everywhere.

Python 3.9 compatible — no match/case, no |union syntax, no tomllib.
"""

from __future__ import annotations

import math
from typing import Dict, List

NM_PER_MM = 1_000_000  # kipy uses nanometres


def get_footprints(board) -> List[Dict]:
    """Return footprints from a kipy board as a list of plain dicts.

    Each dict has the keys:
        ref             (str)   reference designator
        value           (str)   value field
        footprint_id    (str)   "LibName:FootprintName"
        layer           (str)   "F" or "B"
        pos_x           (float) mm
        pos_y           (float) mm
        rotation        (float) degrees, 0-360 (CCW)
        dnp             (bool)
        exclude_from_bom (bool)

    Footprints with empty or placeholder refs (REF**, ~*) are skipped.
    """
    result: List[Dict] = []
    try:
        footprints = list(board.get_footprints())
    except Exception:
        return result

    for fp in footprints:
        try:
            ref = fp.reference_field.text.value
        except Exception:
            continue

        if not ref or ref.startswith("~") or ref in ("REF**", ""):
            continue

        try:
            value = fp.value_field.text.value
        except Exception:
            value = ""

        try:
            fp_id = "{}:{}".format(fp.definition.id.library, fp.definition.id.name)
        except Exception:
            fp_id = ""

        # Layer: "B" for back copper, "F" for everything else.
        # We check both the BoardLayer enum (real kipy) and the raw integer
        # value (31 = back copper) to work in test environments where kipy is
        # mocked and BoardLayer.BL_B_Cu is a MagicMock.
        layer = "F"
        try:
            layer_raw = fp.layer
            # Numeric check: kipy back-copper is integer 31
            layer_int = layer_raw.value if hasattr(layer_raw, "value") else layer_raw
            if layer_int == 31:
                layer = "B"
            else:
                # Enum check: real kipy BoardLayer enum comparison
                try:
                    # Only treat as back copper if the enum is a real class
                    # (not a MagicMock), to avoid false positives in tests.
                    import inspect

                    from kipy.board import BoardLayer  # type: ignore[import]

                    if inspect.isclass(BoardLayer) and layer_raw == BoardLayer.BL_B_Cu:
                        layer = "B"
                except Exception:
                    pass
        except Exception:
            layer = "F"

        # Position in mm
        try:
            pos_x = fp.position.x / NM_PER_MM
            pos_y = fp.position.y / NM_PER_MM
        except Exception:
            pos_x = 0.0
            pos_y = 0.0

        # Rotation: convert from radians, normalize 0-360
        rotation = 0.0
        try:
            rad = fp.orientation.to_radians()
            deg = math.degrees(rad) % 360.0
            rotation = deg
        except Exception:
            rotation = 0.0

        # Attribute flags
        dnp = False
        exclude_from_bom = False
        try:
            attrs = fp.attributes
            dnp = bool(attrs.do_not_populate)
            exclude_from_bom = bool(attrs.exclude_from_bill_of_materials)
        except Exception:
            pass

        result.append(
            {
                "ref": ref,
                "value": value,
                "footprint_id": fp_id,
                "layer": layer,
                "pos_x": pos_x,
                "pos_y": pos_y,
                "rotation": rotation,
                "dnp": dnp,
                "exclude_from_bom": exclude_from_bom,
            }
        )

    return result


def get_bounding_box(fp) -> Dict[str, float]:
    """Return {"w": float, "h": float} bounding box in mm for a footprint.

    Tries courtyard bounding box first, then pads bounding box, then
    falls back to a default 5x5 mm box.
    """
    _DEFAULT: Dict[str, float] = {"w": 5.0, "h": 5.0}

    # Try to get courtyard or general bounding box from kipy
    try:
        bb = fp.bounding_box
        if bb is not None:
            w = abs(bb.width) / NM_PER_MM
            h = abs(bb.height) / NM_PER_MM
            if w > 0 and h > 0:
                return {"w": w, "h": h}
    except Exception:
        pass

    # Try pads bounding box
    try:
        pads = list(fp.definition.pads)
        if pads:
            xs = [p.position.x for p in pads]
            ys = [p.position.y for p in pads]
            # Estimate pad extents using pad size if available
            pad_ws = []
            pad_hs = []
            for p in pads:
                try:
                    pad_ws.append(p.size.x)
                    pad_hs.append(p.size.y)
                except Exception:
                    pad_ws.append(0)
                    pad_hs.append(0)
            min_x = min(xs[i] - pad_ws[i] / 2 for i in range(len(pads)))
            max_x = max(xs[i] + pad_ws[i] / 2 for i in range(len(pads)))
            min_y = min(ys[i] - pad_hs[i] / 2 for i in range(len(pads)))
            max_y = max(ys[i] + pad_hs[i] / 2 for i in range(len(pads)))
            w = (max_x - min_x) / NM_PER_MM
            h = (max_y - min_y) / NM_PER_MM
            if w > 0 and h > 0:
                return {"w": w, "h": h}
    except Exception:
        pass

    return _DEFAULT
