"""Layer plotting and kicad-cli helpers.

Python 3.9 compatible — no match/case, no |union syntax, no tomllib.
"""

from __future__ import annotations

import os
import pathlib
import platform
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple

# Logical layer name -> kicad-cli layer name
LAYER_MAP: Dict[str, str] = {
    "f_mask": "F.Mask",
    "f_paste": "F.Paste",
    "edge_cuts": "Edge.Cuts",
    "f_silks": "F.SilkS",
    "pth_drills": "PTH",
    "npth_drills": "NPTH",
}

# Candidate paths checked in order when kicad-cli is not on PATH
_KICAD_CLI_CANDIDATES = [
    "/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli",
    "/usr/local/bin/kicad-cli",
    "/usr/bin/kicad-cli",
]


def find_kicad_cli() -> Optional[str]:
    """Return the path to kicad-cli, or None if not found.

    Search order:
    1. PATH via shutil.which
    2. Hard-coded candidate paths (macOS app bundle, /usr/local/bin, /usr/bin)
    """
    found = shutil.which("kicad-cli")
    if found:
        return found
    return next((c for c in _KICAD_CLI_CANDIDATES if os.path.exists(c)), None)


def export_layer_svg(
    board_path: str,
    layer: str,
    output_path: str,
    kicad_cli: Optional[str] = None,
) -> None:
    """Export a single PCB layer as SVG using kicad-cli.

    Uses --page-size-mode 2 (fit to board bounds) so all exported SVGs share
    the same coordinate system as the board outline.

    Args:
        board_path:  Absolute path to the .kicad_pcb file.
        layer:       kicad-cli layer name, e.g. "F.Mask" or "Edge.Cuts".
                     Use LAYER_MAP to convert from logical names.
        output_path: Destination path for the SVG file.
        kicad_cli:   Path to kicad-cli binary.  If None, find_kicad_cli() is
                     called automatically.

    Raises:
        RuntimeError: kicad-cli was not found, or the export command failed.
    """
    cli = kicad_cli or find_kicad_cli()
    if not cli:
        raise RuntimeError("kicad-cli not found. Install KiCad or add kicad-cli to PATH.")

    cmd = [
        cli,
        "pcb",
        "export",
        "svg",
        "--layers",
        layer,
        "--page-size-mode",
        "2",
        "--output",
        output_path,
        board_path,
    ]

    env = os.environ.copy()
    # macOS: make sure KiCad's frameworks are reachable
    env.setdefault(
        "DYLD_FRAMEWORK_PATH",
        "/Applications/KiCad/KiCad.app/Contents/Frameworks",
    )
    env.setdefault(
        "DYLD_LIBRARY_PATH",
        "/Applications/KiCad/KiCad.app/Contents/Frameworks",
    )

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=60,
        env=env,
    )

    if result.returncode != 0 or not os.path.exists(output_path):
        raise RuntimeError(
            "kicad-cli SVG export failed (exit {}): {}".format(
                result.returncode,
                result.stderr.strip()[:300],
            )
        )


# ---------------------------------------------------------------------------
# Footprint library resolution
# ---------------------------------------------------------------------------

# Candidate base directories for KiCad's bundled footprint libraries.
_KICAD_FP_DIR_CANDIDATES: List[str] = [
    "/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints",
    "/usr/share/kicad/footprints",
    "/usr/local/share/kicad/footprints",
]


def _fp_lib_table_candidates(board_path: Optional[str] = None):
    """Yield candidate fp-lib-table file paths, most-specific first."""
    if board_path:
        local = pathlib.Path(board_path).parent / "fp-lib-table"
        if local.exists():
            yield str(local)

    if platform.system() == "Darwin":
        base = pathlib.Path.home() / "Library" / "Preferences" / "kicad"
    else:
        base = pathlib.Path.home() / ".config" / "kicad"

    if base.exists():
        try:
            ver_dirs = sorted(
                [d for d in base.iterdir() if d.is_dir()],
                key=lambda d: d.name,
                reverse=True,
            )
            for vd in ver_dirs:
                candidate = vd / "fp-lib-table"
                if candidate.exists():
                    yield str(candidate)
        except OSError:
            pass


def _expand_fp_lib_vars(uri: str) -> str:
    """Expand ${KICAD*_FOOTPRINT_DIR} variables in a library URI."""
    for var in (
        "KICAD9_FOOTPRINT_DIR",
        "KICAD8_FOOTPRINT_DIR",
        "KICAD7_FOOTPRINT_DIR",
        "KICAD_FOOTPRINT_DIR",
    ):
        token = "${" + var + "}"
        if token in uri:
            env_val = os.environ.get(var)
            if env_val:
                return uri.replace(token, env_val)
            for cand in _KICAD_FP_DIR_CANDIDATES:
                if os.path.exists(cand):
                    return uri.replace(token, cand)
    return uri


def _lookup_lib_in_table(table_path: str, nickname: str) -> Optional[str]:
    """Parse a KiCad fp-lib-table and return the URI for the given nickname."""
    try:
        with open(table_path, encoding="utf-8") as f:
            content = f.read()
    except OSError:
        return None

    # Each lib entry looks like:  (lib (name "nick") ... (uri "path") ...)
    # We scan for (name "nick") inside a lib block, then find the nearby uri.
    lib_pat = re.compile(r"\(lib\b([^()]*(?:\([^()]*\)[^()]*)*)\)", re.DOTALL)
    name_pat = re.compile(r'\(name\s+"([^"]+)"\)')
    uri_pat = re.compile(r'\(uri\s+"([^"]+)"\)')

    for lib_m in lib_pat.finditer(content):
        body = lib_m.group(1)
        name_m = name_pat.search(body)
        uri_m = uri_pat.search(body)
        if name_m and uri_m and name_m.group(1) == nickname:
            return _expand_fp_lib_vars(uri_m.group(2))
    return None


def resolve_fp_library(nickname: str, board_path: Optional[str] = None) -> Optional[str]:
    """Resolve a footprint library nickname to its .pretty directory path.

    Searches the project-local fp-lib-table first, then the global user table.
    Returns the resolved directory path, or None if not found.
    """
    for table_path in _fp_lib_table_candidates(board_path):
        uri = _lookup_lib_in_table(table_path, nickname)
        if uri and os.path.isdir(uri):
            return uri
    return None


# ---------------------------------------------------------------------------
# Footprint SVG export
# ---------------------------------------------------------------------------


def parse_svg_viewbox(svg_path: str) -> Optional[Tuple[float, float, float, float]]:
    """Return (x, y, width, height) from an SVG file's viewBox attribute, or None."""
    try:
        tree = ET.parse(svg_path)
        root = tree.getroot()
        # The attribute may appear with or without the SVG namespace prefix.
        vb = None
        for attr_name, val in root.attrib.items():
            if attr_name == "viewBox" or attr_name.lower().endswith("}viewbox"):
                vb = val
                break
        if vb:
            parts = vb.strip().split()
            if len(parts) == 4:
                return (
                    float(parts[0]),
                    float(parts[1]),
                    float(parts[2]),
                    float(parts[3]),
                )
    except Exception:
        pass
    return None


def export_footprint_svg(
    library_path: str,
    footprint_name: str,
    layers: str,
    output_path: str,
    kicad_cli: Optional[str] = None,
) -> None:
    """Export a footprint from a .pretty library as an SVG using kicad-cli.

    Args:
        library_path:   Path to the .pretty library directory.
        footprint_name: Footprint name within the library (no library prefix).
        layers:         Comma-separated layer string, e.g. "F.Courtyard,F.Cu,F.Mask".
        output_path:    Destination path for the produced SVG file.
        kicad_cli:      Explicit path to kicad-cli.  None = auto-locate.

    Raises:
        RuntimeError: kicad-cli was not found or the export failed.
    """
    cli = kicad_cli or find_kicad_cli()
    if not cli:
        raise RuntimeError("kicad-cli not found. Install KiCad or add kicad-cli to PATH.")

    with tempfile.TemporaryDirectory() as tmp_dir:
        cmd = [
            cli,
            "fp",
            "export",
            "svg",
            "--black-and-white",
            "--layers",
            layers,
            "--output",
            tmp_dir,
            library_path,
            footprint_name,
        ]

        env = os.environ.copy()
        env.setdefault(
            "DYLD_FRAMEWORK_PATH",
            "/Applications/KiCad/KiCad.app/Contents/Frameworks",
        )
        env.setdefault(
            "DYLD_LIBRARY_PATH",
            "/Applications/KiCad/KiCad.app/Contents/Frameworks",
        )

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )

        if result.returncode != 0:
            raise RuntimeError(
                "kicad-cli fp export svg failed (exit {}): {}".format(
                    result.returncode,
                    result.stderr.strip()[:300],
                )
            )

        # kicad-cli writes <footprint_name>.svg in the output directory.
        expected = os.path.join(tmp_dir, footprint_name + ".svg")
        if not os.path.exists(expected):
            svg_files = [f for f in os.listdir(tmp_dir) if f.endswith(".svg")]
            if not svg_files:
                raise RuntimeError(
                    "kicad-cli fp export produced no SVG files in {}".format(tmp_dir)
                )
            expected = os.path.join(tmp_dir, svg_files[0])

        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        shutil.copy2(expected, output_path)
